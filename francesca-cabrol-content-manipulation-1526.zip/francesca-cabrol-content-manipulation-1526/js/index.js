// Get all buttons in a NODE LIST of buttons (array like structure) 
// References to activate HTML elements 
const resources = {
    btns: document.querySelectorAll('.controls ul li button'),
    dc: document.querySelector('.dynamic-content')
}; 

/*
Complete your resource-object that will store the dynamic content.
Resource object should 3 sub-objects. Give your sub-objects meaningful names. 
Every sub-object should have the following properties headingContent, bodyText, imgUrl and imgAlt. 
*/

// database 
const contents = {
    c1: {
        heading: 'Roses',
        bodyText: 'This body text blongs to content 1', 
        imageUrl: 'http://127.0.0.1:5501/francesca-cabrol-content-manipulation-1526/img/rose.jpg',
        imageAlt: 'alternative text for image 1'
    },
    c2: {
        heading: 'Hydrangeas',
        bodyText: 'This body text blongs to content 2', 
        imageUrl: 'http://via.placeholder.com/300x300/0000ff',
        imageAlt: 'alternative text for image 2'
    },
    c3: {
        heading: 'Carnations',
        bodyText: 'This body text blongs to content 3', 
        imageUrl: 'http://via.placeholder.com/300x300/ffff00',
        imageAlt: 'alternative text for image 3'
    }
};
   
// Get the reference to your HTML-container that will be dynamically loaded from the resource-object.

// Losding initial content (on the page load)
resources.dc.innerHTML = `<h2>${contents.c1.heading}</h2>`; 

//When button is clicked, content is updated 
let handleclick = ev => {
    // fetch the reference to the current button 
    let currentButton = ev.target; 
    // extract the value of data attribute 
    let currentContent = currentButton.dataset.btn;
    // updated the content 
    resources.dc.innerHTML = `<h2>${contents[currentContent].heading}</h2>
                              <p>${contents[currentContent].bodyText}</p>
                              <figure>
                              <img scr="${contents[currentContent].imageUrl}" alt="${contents[currentContent].imageAlt}"
                              </figure>
    `; 
}

// register all 3 buttons from click event 
for (let btn of resources.btns){
    btn.addEventListener('click', handleclick);
}

/* 
The first button in a NODE LIST of buttons will initially have the id: 
active-button - this will uniquely style the active button (CSS rule). */


    /*The first content from the
    resource-object will be loaded on the page load:
    `<h1>${headingContent}</h1>
     <img src="${imgUrl}" alt="${imgAlt}">
     <p>${bodyText}</p>` */
    
    /* 
    Start your handleSelection function here. */ 
    function handleSelection() {
       /* 
        Remove the id active-button from the element that
        contains it prior to the click-event. 

        This will require the loop throught the NODE LIST of buttons. 
        Inside the loop, use conditional and the element object method
        hasAttribute() to check if the current button in the loop containes the id.
        If it does, use element-object property removeAttribute()
        to remove the id. */

        /*
        Use the element-object method setAttribute() to set the id active-button 
        to the currently clicked button. */
    
        /* 
        Use conditional and event-object to check which button is clicked
        and based on that, create HTML with the data inside the backticks:
        `<h1>${headingContent}</h1>
         <img src="${imgUrl}" alt="${imgAlt}">
         <p>${bodyText}</p>`
        Assign this content to to your HTML-container that will 
        be dynamically loaded (you already got the reference to 
        this container before you started the function handleSelection) */ 
    }
        
        
    
    /* 
    Close your handleSelection function here. */  
    
    /* 
    Register all buttons to click event. The event-handler handleSelection will listen 
    for this event to happen. */ 



// Code aside refreshing associate arrays/ objects 
/*let person = {
    firstName: 'Dan', 
    lastName: 'Gibson'
};

let person = {
    'firstName': 'Dan', 
    'lastName': 'Gibson'
};

console.log(person.firstName); // Prints Dan 
console.log(person["firstName"]); // Prints Dan */